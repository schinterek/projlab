package projlab;

// <<singleton>>
public class BoxCounter {
	// A palyan levo Box-ok szamat tartja nyilvan.
	
	private int numOfBoxes;
	private Game game;
	
	public void boxDisappeared(){
		System.out.println("BoxCounter boxDisappeared fv");
		// Ha egy Box lyukba esett, vagy a helyere kerult,
		// azaz eltunt, csokkenti a Box-ok szamat 1-gyel.
		
		// TODO
	}

}
